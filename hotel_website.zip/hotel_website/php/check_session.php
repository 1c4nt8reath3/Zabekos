<?php
require_once __DIR__ . '/config.php';

header('Content-Type: application/json');

$logged = isLoggedIn();

echo json_encode(['logged_in' => $logged]);
exit();
?>

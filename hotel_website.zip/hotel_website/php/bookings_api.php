<?php
require_once __DIR__ . '/config.php';

header('Content-Type: application/json');

if (!isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['error' => 'Not authenticated']);
    exit();
}

$conn = getDBConnection();
$sql = "SELECT b.id, b.check_in, b.check_out, b.total_price, b.status, r.room_type, r.room_number
        FROM bookings b
        JOIN rooms r ON b.room_id = r.id
        WHERE b.user_id = ?
        ORDER BY b.check_in DESC";

$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $_SESSION['user_id']);
$stmt->execute();
$result = $stmt->get_result();

$rows = [];
while ($row = $result->fetch_assoc()) {
    $rows[] = [
        'id' => (int)$row['id'],
        'room_type' => $row['room_type'],
        'room_number' => $row['room_number'],
        'check_in' => $row['check_in'],
        'check_out' => $row['check_out'],
        'total_price' => (float)$row['total_price'],
        'status' => $row['status']
    ];
}

echo json_encode(['bookings' => $rows]);

$stmt->close();
$conn->close();
exit();
?>

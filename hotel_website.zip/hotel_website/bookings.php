<?php
require_once 'php/config.php';

// Require login
requireLogin();

$conn = getDBConnection();
$sql = "SELECT b.id, b.check_in, b.check_out, b.total_price, b.status, r.room_type, r.room_number
        FROM bookings b
        JOIN rooms r ON b.room_id = r.id
        WHERE b.user_id = ?
        ORDER BY b.check_in DESC";

$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $_SESSION['user_id']);
$stmt->execute();
$result = $stmt->get_result();

function h($s){ return htmlspecialchars($s, ENT_QUOTES, 'UTF-8'); }
?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Your Bookings - Grand Hotel</title>
    <link rel="stylesheet" href="css/styles.css" />
  </head>
  <body>
    <header>
      <nav>
        <div class="container">
          <h1>Grand Hotel</h1>
          <ul>
            <li><a href="index.html">Home</a></li>
            <li><a href="book.html">Book Room</a></li>
            <li><a href="bookings.php">My Bookings</a></li>
            <li><a href="php/logout.php">Logout</a></li>
          </ul>
        </div>
      </nav>
    </header>

    <main>
      <div class="container">
        <section class="form-container">
          <h2>Your Bookings</h2>
          <?php if ($result && $result->num_rows > 0): ?>
            <div class="bookings-table-wrap">
              <table class="bookings-table" aria-live="polite">
                <thead>
                  <tr>
                    <th>Booking ID</th>
                    <th>Room</th>
                    <th>Check-in</th>
                    <th>Check-out</th>
                    <th>Nights</th>
                    <th>Total</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                <?php while($row = $result->fetch_assoc()):
                  $checkIn = new DateTime($row['check_in']);
                  $checkOut = new DateTime($row['check_out']);
                  $nights = $checkIn->diff($checkOut)->days;
                ?>
                  <tr>
                    <td><?php echo h($row['id']); ?></td>
                    <td><?php echo h($row['room_type'] . ' #' . $row['room_number']); ?></td>
                    <td><?php echo h($checkIn->format('Y-m-d')); ?></td>
                    <td><?php echo h($checkOut->format('Y-m-d')); ?></td>
                    <td><?php echo h($nights); ?></td>
                    <td>$<?php echo number_format($row['total_price'], 2); ?></td>
                    <td><?php echo h(ucfirst($row['status'])); ?></td>
                  </tr>
                <?php endwhile; ?>
                </tbody>
              </table>
            </div>
          <?php else: ?>
            <p>You have no bookings yet. <a href="book.html">Make a reservation</a>.</p>
          <?php endif; ?>
        </section>
      </div>
    </main>

    <footer>
      <div class="container">
        <p>&copy; 2023 Grand Hotel. All rights reserved.</p>
      </div>
    </footer>
  </body>
</html>

<?php
$stmt->close();
$conn->close();
?>

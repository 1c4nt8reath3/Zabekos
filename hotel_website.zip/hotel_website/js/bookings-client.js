// Client-side bookings renderer for bookings.html
(function(){
  function el(tag, attrs={}, text){ const e = document.createElement(tag); for(let k in attrs) e.setAttribute(k, attrs[k]); if(text) e.textContent = text; return e; }

  function formatDate(d){ const dt = new Date(d + 'T00:00:00'); if(isNaN(dt)) return d; return dt.toISOString().slice(0,10); }

  function renderTable(bookings){
    if(!bookings || bookings.length === 0){
      return el('p', {}, 'You have no bookings yet. Go to ').appendChild((function(){ const a = el('a',{href:'book.html'},'book a room'); return a; })());
    }

    const wrap = el('div');
    const table = el('table', {class:'bookings-table'});
    const thead = el('thead');
    const headerRow = el('tr');
    ['Booking ID','Room','Check-in','Check-out','Nights','Total','Status'].forEach(h=> headerRow.appendChild(el('th',{},h)));
    thead.appendChild(headerRow);
    table.appendChild(thead);
    const tbody = el('tbody');

    bookings.forEach(b => {
      const tr = el('tr');
      const checkIn = new Date(b.check_in + 'T00:00:00');
      const checkOut = new Date(b.check_out + 'T00:00:00');
      const nights = Math.max(0, Math.round((checkOut - checkIn)/(1000*60*60*24)));

      tr.appendChild(el('td',{}, String(b.id)));
      tr.appendChild(el('td',{}, `${b.room_type} #${b.room_number}`));
      tr.appendChild(el('td',{}, formatDate(b.check_in)));
      tr.appendChild(el('td',{}, formatDate(b.check_out)));
      tr.appendChild(el('td',{}, String(nights)));
      tr.appendChild(el('td',{}, `$${Number(b.total_price).toFixed(2)}`));
      const statusTd = el('td',{}, b.status.charAt(0).toUpperCase() + b.status.slice(1));
      statusTd.className = 'status-' + (b.status || '').toLowerCase();
      tr.appendChild(statusTd);

      tbody.appendChild(tr);
    });

    table.appendChild(tbody);
    wrap.appendChild(table);
    return wrap;
  }

  document.addEventListener('DOMContentLoaded', function(){
    const root = document.getElementById('bookingsRoot');
    if(!root) return;

    // Check session first
    fetch('php/check_session.php', {credentials:'same-origin'}).then(r=>r.json()).then(s=>{
      if(!s.logged_in){
        root.innerHTML = '';
        const p = document.createElement('p');
        p.innerHTML = 'You are not logged in. Please <a href="login.html">login</a> to view your bookings.';
        root.appendChild(p);
        return;
      }

      // fetch bookings data
      fetch('php/bookings_api.php', {credentials:'same-origin'})
        .then(resp => {
          if(resp.status === 401) throw new Error('Not authenticated');
          return resp.json();
        })
        .then(data => {
          root.innerHTML = '';
          const bookings = (data && data.bookings) ? data.bookings : [];
          if(bookings.length === 0){
            const p = el('p',{}, 'You have no bookings yet. ');
            const a = el('a',{href:'book.html'}, 'Make a booking');
            p.appendChild(a);
            root.appendChild(p);
            return;
          }
          const table = renderTable(bookings);
          root.appendChild(table);
        })
        .catch(err => {
          root.innerHTML = '';
          const p = el('p',{}, 'Unable to load bookings. Please try again later.');
          root.appendChild(p);
          console.error(err);
        });
    }).catch(()=>{
      root.innerHTML = '';
      const p = el('p',{}, 'Unable to check session. Please try again later.');
      root.appendChild(p);
    });
  });
})();

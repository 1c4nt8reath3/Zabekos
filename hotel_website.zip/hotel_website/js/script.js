// Interactive booking script
// - calculates nights and total price
// - validates check-in/check-out
// - disables submission when user is not logged in (toggle via server-side flag)

(function(){
  // Prices per room type
  const PRICES = {
    'Single': 100,
    'Double': 150,
    'Suite': 250,
    'Family': 200
  };

  // Start as false; we'll attempt to fetch session status from the server
  let loggedIn = Boolean(window.LOGGED_IN) || false;

  document.addEventListener('DOMContentLoaded', function(){
    const roomTypeEl = document.getElementById('room_type');
    const checkInEl = document.getElementById('check_in');
    const checkOutEl = document.getElementById('check_out');
    const nightsEl = document.getElementById('nights');
    const priceEl = document.getElementById('pricePerNight');
    const totalEl = document.getElementById('totalPrice');
    const dateErrorEl = document.getElementById('dateError');
    const bookBtn = document.getElementById('bookBtn');
    const loginNote = document.getElementById('loginNote');
    const form = document.getElementById('bookingForm');

    function safeDisableButton(disabled){ if(bookBtn) bookBtn.disabled = disabled; }
    function showLoginNote(show){ if(loginNote) loginNote.style.display = show ? 'block' : 'none'; }

    // Fetch session status so static HTML pages can know if user is logged in
    fetch('php/check_session.php', { credentials: 'same-origin' })
      .then(r => r.json())
      .then(data => {
        loggedIn = !!data.logged_in;
        // apply state
        if(!loggedIn){ safeDisableButton(true); showLoginNote(true); }
        else { showLoginNote(false); }
      }).catch(()=>{
        // ignore errors, keep loggedIn as false
        safeDisableButton(true); showLoginNote(true);
      });

    function parseDate(value){ if(!value) return null; const d = new Date(value + 'T00:00:00'); return isNaN(d.getTime()) ? null : d; }
    function calcNights(a,b){ if(!a || !b) return 0; const msPerDay = 1000*60*60*24; const days = Math.round((b.getTime() - a.getTime())/msPerDay); return Math.max(0, days); }

    function updateSummary(){
      if(!roomTypeEl || !checkInEl || !checkOutEl || !nightsEl || !priceEl || !totalEl || !dateErrorEl) return;

      const room = roomTypeEl.value;
      const inDate = parseDate(checkInEl.value);
      const outDate = parseDate(checkOutEl.value);

      dateErrorEl.style.display = 'none'; dateErrorEl.textContent = '';

      if(!room){ priceEl.textContent = '—'; nightsEl.textContent = '—'; totalEl.textContent = '—'; safeDisableButton(true); return; }

      const pricePerNight = PRICES[room] || 0; priceEl.textContent = pricePerNight ? `$${pricePerNight}` : '—';

      if(inDate && outDate){
        const nights = calcNights(inDate, outDate);
        if(nights <= 0){ nightsEl.textContent = '—'; totalEl.textContent = '—'; dateErrorEl.style.display = 'block'; dateErrorEl.textContent = 'Check-out date must be after check-in date.'; safeDisableButton(true); return; }
        nightsEl.textContent = nights; totalEl.textContent = `$${(pricePerNight * nights).toFixed(2)}`;
        safeDisableButton(!loggedIn);
      } else { nightsEl.textContent = '—'; totalEl.textContent = '—'; safeDisableButton(true); }
    }

    // Attach events safely
    [roomTypeEl, checkInEl, checkOutEl].forEach(el=>{ if(!el) return; el.addEventListener('change', updateSummary); el.addEventListener('input', updateSummary); });

    // initial update
    updateSummary();

    // If booking form exists, attach submission handler safely
    if(form){
      form.addEventListener('submit', function(e){
        const inDate = parseDate(checkInEl.value);
        const outDate = parseDate(checkOutEl.value);
        const nights = calcNights(inDate, outDate);
        if(!loggedIn){ e.preventDefault(); alert('You must be logged in to book a room. Please log in first.'); return false; }
        if(nights <= 0){ e.preventDefault(); dateErrorEl.style.display = 'block'; dateErrorEl.textContent = 'Please select valid dates.'; return false; }
      });
    }
  });
})();
// Form validation and interactivity for the hotel website

// Login form validation
document.getElementById("loginForm").addEventListener("submit", function (e) {
  const username = document.getElementById("username").value.trim();
  const password = document.getElementById("password").value.trim();

  if (!username || !password) {
    e.preventDefault();
    alert("Please fill in all fields.");
    return;
  }

  // Additional client-side validation can be added here
});

// Registration form validation
document
  .getElementById("registerForm")
  .addEventListener("submit", function (e) {
    const username = document.getElementById("username").value.trim();
    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value.trim();
    const confirmPassword = document
      .getElementById("confirm_password")
      .value.trim();

    if (!username || !email || !password || !confirmPassword) {
      e.preventDefault();
      alert("Please fill in all fields.");
      return;
    }

    if (password !== confirmPassword) {
      e.preventDefault();
      alert("Passwords do not match.");
      return;
    }

    if (password.length < 6) {
      e.preventDefault();
      alert("Password must be at least 6 characters long.");
      return;
    }

    // Basic email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      e.preventDefault();
      alert("Please enter a valid email address.");
      return;
    }
  });

// Booking form validation
document.getElementById("bookingForm").addEventListener("submit", function (e) {
  const roomType = document.getElementById("room_type").value;
  const checkIn = document.getElementById("check_in").value;
  const checkOut = document.getElementById("check_out").value;

  if (!roomType || !checkIn || !checkOut) {
    e.preventDefault();
    alert("Please fill in all fields.");
    return;
  }

  const checkInDate = new Date(checkIn);
  const checkOutDate = new Date(checkOut);
  const today = new Date();

  if (checkInDate < today) {
    e.preventDefault();
    alert("Check-in date cannot be in the past.");
    return;
  }

  if (checkOutDate <= checkInDate) {
    e.preventDefault();
    alert("Check-out date must be after check-in date.");
    return;
  }
});

// Function to check if user is logged in (for future use)
function checkLoginStatus() {
  // This would typically check a session or cookie
  // For now, we'll assume the user needs to be redirected to login if not authenticated
  // This can be enhanced with AJAX calls to check session status
}

// Add any additional interactivity here
// For example, dynamic room price calculation based on dates
document
  .getElementById("check_in")
  .addEventListener("change", updateTotalPrice);
document
  .getElementById("check_out")
  .addEventListener("change", updateTotalPrice);
document
  .getElementById("room_type")
  .addEventListener("change", updateTotalPrice);

function updateTotalPrice() {
  const roomType = document.getElementById("room_type").value;
  const checkIn = document.getElementById("check_in").value;
  const checkOut = document.getElementById("check_out").value;

  if (!roomType || !checkIn || !checkOut) return;

  const checkInDate = new Date(checkIn);
  const checkOutDate = new Date(checkOut);
  const nights = Math.ceil(
    (checkOutDate - checkInDate) / (1000 * 60 * 60 * 24),
  );

  let pricePerNight = 0;
  switch (roomType) {
    case "Single":
      pricePerNight = 100;
      break;
    case "Double":
      pricePerNight = 150;
      break;
    case "Suite":
      pricePerNight = 250;
      break;
    case "Family":
      pricePerNight = 200;
      break;
  }

  const totalPrice = nights * pricePerNight;

  // Display total price (you might want to add a span in the HTML for this)
  const totalElement = document.getElementById("total-price");
  if (totalElement) {
    totalElement.textContent = `Total: $${totalPrice}`;
  }
}
